package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IndexPage extends JFrame {

    private Color startColor = new Color(30, 144, 255);  // Initial start color
    private Color endColor = new Color(70, 130, 180);    // Initial end color
    
    public IndexPage() {
        // Initialize JFrame settings
        setTitle("Online Exam System");
        setLayout(new BorderLayout());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        // Add background gradient with animation
        JPanel background = createBackgroundPanel();
        add(background);

        // Add components to the background panel (Home Panel with Login Buttons)
        background.add(createHomePanel(), BorderLayout.CENTER);

        // Make the window visible
        setVisible(true);

        // Timer to animate the gradient colors (change over time)
        Timer timer = new Timer(50, new ActionListener() {
            private float hue = 0f;

            @Override
            public void actionPerformed(ActionEvent e) {
                // Change hue value to animate the gradient color
                hue += 0.01f;
                if (hue > 1f) {
                    hue = 0f;
                }

                // Adjust startColor and endColor based on hue (or any other logic)
                startColor = Color.getHSBColor(hue, 0.7f, 1.0f); // Varying hue for animation
                endColor = Color.getHSBColor(hue + 0.5f, 0.7f, 1.0f); // Shift hue for end color

                repaint(); // Trigger a repaint to apply new gradient
            }
        });

        timer.start(); // Start the animation
    }

    // Create a custom background with animated gradient colors
    private JPanel createBackgroundPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                // Dynamic gradient color based on the window height
                GradientPaint gradient = new GradientPaint(0, 0, startColor, 0, getHeight(), endColor);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BorderLayout());
        return panel;
    }

    // Home Panel with Admin and Student Login Buttons
    private JPanel createHomePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false); // Make the panel transparent to show the background

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel welcome = new JLabel("Welcome to Online Examination System");
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcome.setForeground(Color.WHITE);

        JButton adminLogin = createLoginButton("Admin Login", new Color(30, 144, 255), Color.WHITE);
        JButton studentLogin = createLoginButton("Student Login", new Color(50, 205, 50), Color.WHITE);

        // Action for Admin login button
        adminLogin.addActionListener(e -> {
            dispose();
            new model.AdminLogin(); // Example, adjust based on your implementation
        });

        // Action for Student login button
        studentLogin.addActionListener(e -> {
            dispose();
            new model.StudentLogin(); // Example, adjust based on your implementation
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(welcome, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(adminLogin, gbc);

        gbc.gridx = 1;
        panel.add(studentLogin, gbc);

        return panel;
    }

    // Method to create a stylish login button with hover effect
    private JButton createLoginButton(String text, Color backgroundColor, Color textColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 18)); // Larger font size for better readability
        button.setBackground(backgroundColor);
        button.setForeground(textColor);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(250, 60)); // Adjusted size for a more prominent button
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Adjust button size on resize
        button.setMinimumSize(new Dimension(200, 50));
        button.setMaximumSize(new Dimension(300, 70));

        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });

        return button;
    }

    // Main method to run the app
    public static void main(String[] args) {
        SwingUtilities.invokeLater(IndexPage::new);
    }
}
