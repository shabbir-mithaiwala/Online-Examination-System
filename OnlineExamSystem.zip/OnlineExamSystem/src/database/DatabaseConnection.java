package database;

import java.sql.*;

public class DatabaseConnection {
    private static Connection con;

    public static Connection getConnection() {
        try {
            if (con == null || con.isClosed()) {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

                String dbURL = "jdbc:ucanaccess://D:/OnlineExamSystem/src/database/OnlineExamDB.accdb";
                con = DriverManager.getConnection(dbURL);
                System.out.println("Database Connected Successfully!");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("UCanAccess Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database Connection Failed!");
            e.printStackTrace();
        }
        return con;
    }

    public static void closeConnection(Connection con) {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Database Connection Closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void closeConnection() {
        closeConnection(con);
    }
}
