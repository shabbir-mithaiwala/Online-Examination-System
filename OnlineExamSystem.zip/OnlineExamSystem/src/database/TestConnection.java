package database;

import java.sql.*;

public class TestConnection {
    public static void main(String[] args) {
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
           String dbURL = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=D:\\OnlineExamSystem\\src\\database\\OnlineExamDB.accdb;";



            Connection con = DriverManager.getConnection(dbURL);

            System.out.println("Connected Successfully!");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Admin");

            if (rs.next()) {
                System.out.println("Admin Found: " + rs.getString("Username"));
            } else {
                System.out.println("No Admin Data Found!");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
