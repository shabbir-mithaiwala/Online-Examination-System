package model;

import database.DatabaseConnection;
import ui.AdminPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminLogin {
    private JFrame frame;
    private JTextField userField;
    private JPasswordField passField;
    private JCheckBox showPasswordCheckBox;
    private JButton forgotPasswordButton;
    private JButton loginButton;
    private JButton registerButton;
    private JLabel captchaLabel;
    private JTextField captchaAnswerField;
    private int captchaResult;
    private boolean isDarkMode = false;

    public AdminLogin() {
        frame = new JFrame("Admin Login");
        frame.setSize(350, 350);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // User field and password field
        JLabel userLabel = new JLabel("Username:");
        userField = new JTextField(15);
        
        JLabel passLabel = new JLabel("Password:");
        passField = new JPasswordField(15);
        passField.setToolTipText("Enter your password");

        // Show password checkbox
        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                passField.setEchoChar(showPasswordCheckBox.isSelected() ? (char) 0 : '*');
            }
        });

        // Forgot password button
        forgotPasswordButton = new JButton("Forgot Password?");
        forgotPasswordButton.setForeground(Color.BLUE);
        forgotPasswordButton.setBorderPainted(false);
        forgotPasswordButton.setContentAreaFilled(false);
        forgotPasswordButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgotPasswordButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminForgotPassword();
            }
        });

        // CAPTCHA
        captchaLabel = new JLabel();
        captchaAnswerField = new JTextField(10);
        generateCaptcha();

        // Login button
        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });

        // Registration button
        registerButton = new JButton("Register New Admin");
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showRegistrationForm();
            }
        });

        // Dark/Light Mode Toggle
        final JToggleButton themeToggleButton = new JToggleButton("Switch to Dark Mode");
        themeToggleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                toggleTheme(themeToggleButton);
            }
        });

// Group Show Password + Forgot Password
JPanel passwordOptionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
passwordOptionsPanel.setOpaque(false);
passwordOptionsPanel.add(showPasswordCheckBox);
passwordOptionsPanel.add(forgotPasswordButton);

// Group Login + Register buttons
JPanel actionButtonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
actionButtonsPanel.setOpaque(false);
actionButtonsPanel.add(loginButton);
actionButtonsPanel.add(registerButton);

// Layout using GridBagLayout
gbc.gridx = 0; gbc.gridy = 0; frame.add(userLabel, gbc);
gbc.gridx = 1; frame.add(userField, gbc);

gbc.gridx = 0; gbc.gridy = 1; frame.add(passLabel, gbc);
gbc.gridx = 1; frame.add(passField, gbc);

gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; frame.add(passwordOptionsPanel, gbc);

gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1; frame.add(captchaLabel, gbc);
gbc.gridx = 1; frame.add(captchaAnswerField, gbc);

gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; frame.add(actionButtonsPanel, gbc);

gbc.gridy = 5; frame.add(themeToggleButton, gbc);


        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

private void handleLogin() {
    final String username = userField.getText(); // ✅ final, so it's usable in anonymous class later too if needed

    String password = new String(passField.getPassword());
    String captchaAnswer = captchaAnswerField.getText();

    if (username.isEmpty() || password.isEmpty() || captchaAnswer.isEmpty()) {
        JOptionPane.showMessageDialog(frame, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (!captchaAnswer.equals(String.valueOf(captchaResult))) {
        JOptionPane.showMessageDialog(frame, "CAPTCHA incorrect!", "Error", JOptionPane.ERROR_MESSAGE);
        generateCaptcha();
        captchaAnswerField.setText("");
        return;
    }

    int authResult = authenticateAdmin(username, password);
    if (authResult == 1) {
        JOptionPane.showMessageDialog(frame, "Login Successful!");
        frame.dispose(); // Close the login frame
        new AdminPanel(username); // Open the Admin Panel
    } else if (authResult == -1) {
        JOptionPane.showMessageDialog(frame, "Invalid Username!", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(frame, "Incorrect Password!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    generateCaptcha();
    captchaAnswerField.setText("");
}


    private int authenticateAdmin(String username, String password) {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.getConnection();
            if (con == null) {
                JOptionPane.showMessageDialog(frame, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
                return -1;
            }

            String userCheckQuery = "SELECT Password FROM Admin WHERE Username=?";
            pst = con.prepareStatement(userCheckQuery);
            pst.setString(1, username);
            rs = pst.executeQuery();

            if (!rs.next()) {
                return -1;
            }

            String storedPassword = rs.getString("Password");
            return storedPassword.equals(password) ? 1 : 0;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            try { if (pst != null) pst.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            try { if (con != null) con.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }

        return -1;
    }

    private void generateCaptcha() {
        int a = (int) (Math.random() * 10 + 1);
        int b = (int) (Math.random() * 10 + 1);
        char[] ops = {'+', '-', '*'};
        char op = ops[(int) (Math.random() * ops.length)];

        switch (op) {
            case '+': captchaResult = a + b; break;
            case '-': captchaResult = a - b; break;
            case '*': captchaResult = a * b; break;
        }

        captchaLabel.setText("What is " + a + " " + op + " " + b + "?");
    }

    private void toggleTheme(JToggleButton toggleButton) {
        isDarkMode = !isDarkMode;
        updateTheme(frame.getContentPane());
        toggleButton.setText(isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode");
        frame.repaint();
    }

    private void updateTheme(Container container) {
        Color bg = isDarkMode ? Color.DARK_GRAY : Color.WHITE;
        Color fg = isDarkMode ? Color.WHITE : Color.BLACK;

        Component[] components = container.getComponents();
        for (Component c : components) {
            c.setBackground(bg);

            if (c instanceof JLabel || c instanceof JButton || c instanceof JCheckBox || c instanceof JTextField || c instanceof JPasswordField) {
                c.setForeground(fg);
            }

            if (c instanceof Container) {
                updateTheme((Container) c);
            }
        }
        container.setBackground(bg);
    }

   private void showRegistrationForm() {
    final JFrame registerFrame = new JFrame("Admin Registration");
    registerFrame.setSize(350, 350);
    registerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    registerFrame.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    // Declare the fields as final
    final JTextField regUserField = new JTextField(15);
    final JPasswordField regPassField = new JPasswordField(15);

    JLabel regUserLabel = new JLabel("Username:");
    JLabel regPassLabel = new JLabel("Password:");

    JButton registerSubmitButton = new JButton("Register");
    registerSubmitButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            // Now these can be used inside the anonymous class because they are final
            String username = regUserField.getText();
            String password = new String(regPassField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(registerFrame, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (registerAdmin(username, password)) {
                JOptionPane.showMessageDialog(registerFrame, "Registration Successful!");
                registerFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(registerFrame, "Registration Failed. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    gbc.gridx = 0; gbc.gridy = 0; registerFrame.add(regUserLabel, gbc);
    gbc.gridx = 1; registerFrame.add(regUserField, gbc);

    gbc.gridx = 0; gbc.gridy = 1; registerFrame.add(regPassLabel, gbc);
    gbc.gridx = 1; registerFrame.add(regPassField, gbc);

    gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; registerFrame.add(registerSubmitButton, gbc);

    registerFrame.setLocationRelativeTo(null);
    registerFrame.setVisible(true);
}

    private boolean registerAdmin(String username, String password) {
    Connection con = null;
    PreparedStatement pst = null;

    try {
        con = DatabaseConnection.getConnection();
        if (con == null) {
            return false;
        }

        // Check if the username already exists
        String checkQuery = "SELECT * FROM Admin WHERE Username=?";
        pst = con.prepareStatement(checkQuery);
        pst.setString(1, username);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "Username already exists. Please choose a different one.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Insert the new admin without the email field
        String insertQuery = "INSERT INTO Admin (Username, Password) VALUES (?, ?)";
        pst = con.prepareStatement(insertQuery);
        pst.setString(1, username);
        pst.setString(2, password);

        return pst.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        try { if (pst != null) pst.close(); } catch (SQLException ignored) {}
        try { if (con != null) con.close(); } catch (SQLException ignored) {}
    }
}
public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
        public void run() {
            new AdminLogin(); // ✅ Starts with login screen
        }
    });
}

}
