package model;

import database.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ExamForm extends JFrame {
    private JTextField titleField, durationField;
    private JButton saveButton, cancelButton;

    private DefaultTableModel examModel;
    private String createdBy;

    public ExamForm(DefaultTableModel examModel, String createdBy) {
        this.examModel = examModel;
        this.createdBy = createdBy;

        setTitle("Create Exam");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel titleLabel = new JLabel("Exam Title:");
        titleField = new JTextField(20);
        JLabel durationLabel = new JLabel("Duration (min):");
        durationField = new JTextField(5);
        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");

        gbc.gridx = 0; gbc.gridy = 0; add(titleLabel, gbc);
        gbc.gridx = 1; add(titleField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; add(durationLabel, gbc);
        gbc.gridx = 1; add(durationField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; add(saveButton, gbc);
        gbc.gridx = 1; add(cancelButton, gbc);

        saveButton.addActionListener(e -> saveExam());
        cancelButton.addActionListener(e -> dispose());

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void saveExam() {
        String title = titleField.getText().trim();
        String durationStr = durationField.getText().trim();

        if (title.isEmpty() || durationStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int duration;
        try {
            duration = Integer.parseInt(durationStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid duration format!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection con = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Exam (ExamName, Duration, CreatedBy) VALUES (?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, title);
            pst.setInt(2, duration);
            pst.setString(3, createdBy);

            int affectedRows = pst.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = pst.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int examId = generatedKeys.getInt(1);
                    examModel.addRow(new Object[]{examId, title, duration, "Edit", "Delete"});
                    JOptionPane.showMessageDialog(this, "Exam saved successfully!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save exam.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        dispose();
    }
}
