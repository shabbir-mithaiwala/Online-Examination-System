package model;

import database.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminForgotPassword {
    private JFrame frame;
    private JTextField userField, newPassField, captchaAnswerField;
    private JLabel captchaLabel;
    private int captchaResult;
    private JButton resetButton;

    public AdminForgotPassword() {
        frame = new JFrame("Forgot Password - Admin");
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userLabel = new JLabel("Username:");
        userField = new JTextField(15);
        JLabel newPassLabel = new JLabel("New Password:");
        newPassField = new JTextField(15);
        captchaLabel = new JLabel();
        captchaAnswerField = new JTextField(10);
        generateCaptcha();

        resetButton = new JButton("Reset Password");
        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetPassword();
            }
        });

        gbc.gridx = 0; gbc.gridy = 0; frame.add(userLabel, gbc);
        gbc.gridx = 1; frame.add(userField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; frame.add(newPassLabel, gbc);
        gbc.gridx = 1; frame.add(newPassField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; frame.add(captchaLabel, gbc);
        gbc.gridx = 1; frame.add(captchaAnswerField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; frame.add(resetButton, gbc);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void generateCaptcha() {
        int a = (int) (Math.random() * 10 + 1);
        int b = (int) (Math.random() * 10 + 1);
        captchaResult = a + b;
        captchaLabel.setText("What is " + a + " + " + b + "?");
    }

    private void resetPassword() {
        String username = userField.getText();
        String newPassword = newPassField.getText();
        String captchaInput = captchaAnswerField.getText();

        if (username.isEmpty() || newPassword.isEmpty() || captchaInput.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!captchaInput.equals(String.valueOf(captchaResult))) {
            JOptionPane.showMessageDialog(frame, "Incorrect CAPTCHA!", "Error", JOptionPane.ERROR_MESSAGE);
            generateCaptcha();
            captchaAnswerField.setText("");
            return;
        }

        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = DatabaseConnection.getConnection();
            pst = con.prepareStatement("UPDATE Admin SET Password=? WHERE Username=?");
            pst.setString(1, newPassword);
            pst.setString(2, username);

            int rowsUpdated = pst.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(frame, "Password Reset Successfully!");
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (pst != null) pst.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            try { if (con != null) con.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AdminForgotPassword();
            }
        });
    }
}
