package model;

import database.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ForgotPassword {
    private JFrame frame;
    private JTextField studentIdField;
    private JPasswordField newPasswordField;
    private JButton resetButton;

    public ForgotPassword() {
        frame = new JFrame("Forgot Password");
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel studentIdLabel = new JLabel("Enter Student ID:");
        studentIdField = new JTextField(15);
        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordField = new JPasswordField(15);
        resetButton = new JButton("Reset Password");

        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resetPassword();
            }
        });

        gbc.gridx = 0; gbc.gridy = 0; frame.add(studentIdLabel, gbc);
        gbc.gridx = 1; frame.add(studentIdField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; frame.add(newPasswordLabel, gbc);
        gbc.gridx = 1; frame.add(newPasswordField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; frame.add(resetButton, gbc);

        frame.setVisible(true);
    }

    private void resetPassword() {
        String studentId = studentIdField.getText();
        String newPassword = new String(newPasswordField.getPassword());

        if (studentId.isEmpty() || newPassword.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = DatabaseConnection.getConnection();
            if (con == null) {
                JOptionPane.showMessageDialog(frame, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check if Student ID exists
            String checkQuery = "SELECT * FROM Student WHERE StudentID=?";
            pst = con.prepareStatement(checkQuery);
            pst.setString(1, studentId);
            ResultSet rs = pst.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(frame, "Invalid Student ID!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Update Password
            String updateQuery = "UPDATE Student SET Password=? WHERE StudentID=?";
            pst = con.prepareStatement(updateQuery);
            pst.setString(1, newPassword);
            pst.setString(2, studentId);

            int updated = pst.executeUpdate();
            if (updated > 0) {
                JOptionPane.showMessageDialog(frame, "Password Reset Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                frame.dispose();
            } else {
                JOptionPane.showMessageDialog(frame, "Password Reset Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pst != null) pst.close();
                DatabaseConnection.closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new ForgotPassword();
    }
}
