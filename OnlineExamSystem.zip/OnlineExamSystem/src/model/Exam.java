package model;
import java.io.Serializable;

public class Exam implements Serializable {
    private int examId;
    private String examName;
    private int duration;

    public Exam(int examId, String examName, int duration) {
        this.examId = examId;
        this.examName = examName;
        this.duration = duration;
    }

    // Getters and Setters
    public int getExamId() { return examId; }
    public void setExamId(int examId) { this.examId = examId; }

    public String getExamName() { return examName; }
    public void setExamName(String examName) { this.examName = examName; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }
}
