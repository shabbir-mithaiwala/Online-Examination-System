package model;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;

public class QuestionForm extends JFrame {
    private JTextField questionField;
    private JTextField optionAField, optionBField, optionCField, optionDField;
    private JComboBox<String> correctAnswerBox; 
    private JButton saveButton, cancelButton;
    private DefaultTableModel questionModel;

    public QuestionForm(DefaultTableModel questionModel) { // ✅ Accepts table model
        this.questionModel = questionModel;

        setTitle("Add Question");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel questionLabel = new JLabel("Question:");
        questionField = new JTextField(20);
        JLabel optionALabel = new JLabel("Option A:");
        optionAField = new JTextField(20);
        JLabel optionBLabel = new JLabel("Option B:");
        optionBField = new JTextField(20);
        JLabel optionCLabel = new JLabel("Option C:");
        optionCField = new JTextField(20);
        JLabel optionDLabel = new JLabel("Option D:");
        optionDField = new JTextField(20);
        JLabel correctAnswerLabel = new JLabel("Correct Answer:");

        correctAnswerBox = new JComboBox<String>(new String[]{"A", "B", "C", "D"}); // ✅ Remove diamond operator

        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");

        gbc.gridx = 0; gbc.gridy = 0; add(questionLabel, gbc);
        gbc.gridx = 1; add(questionField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; add(optionALabel, gbc);
        gbc.gridx = 1; add(optionAField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; add(optionBLabel, gbc);
        gbc.gridx = 1; add(optionBField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; add(optionCLabel, gbc);
        gbc.gridx = 1; add(optionCField, gbc);
        gbc.gridx = 0; gbc.gridy = 4; add(optionDLabel, gbc);
        gbc.gridx = 1; add(optionDField, gbc);
        gbc.gridx = 0; gbc.gridy = 5; add(correctAnswerLabel, gbc);
        gbc.gridx = 1; add(correctAnswerBox, gbc);
        gbc.gridx = 0; gbc.gridy = 6; add(saveButton, gbc);
        gbc.gridx = 1; add(cancelButton, gbc);

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveQuestion();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void saveQuestion() {
        String question = questionField.getText();
        String optionA = optionAField.getText();
        String optionB = optionBField.getText();
        String optionC = optionCField.getText();
        String optionD = optionDField.getText();
        String correctAnswer = (String) correctAnswerBox.getSelectedItem(); // ✅ Cast to String

        if (question.isEmpty() || optionA.isEmpty() || optionB.isEmpty() || optionC.isEmpty() || optionD.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ✅ Add question details to table model
        questionModel.addRow(new Object[]{null, null, question, correctAnswer});

        JOptionPane.showMessageDialog(this, "Question saved successfully!");
        dispose();
    }
}
