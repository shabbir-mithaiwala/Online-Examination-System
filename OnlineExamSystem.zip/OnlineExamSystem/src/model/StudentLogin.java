
package model;

import database.DatabaseConnection;
import ui.StudentPanel;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.regex.Pattern;

public class StudentLogin {
    private JFrame frame;
    private JTextField studentIdField;
    private JPasswordField passField;
    private JCheckBox showPasswordCheckBox;
    private JButton forgotPasswordButton;
    private boolean isDarkTheme = false;

    public StudentLogin() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}

        frame = new JFrame("Student Login");
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridBagLayout());

        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.insets = new Insets(10, 10, 10, 10);
        gbcMain.fill = GridBagConstraints.BOTH;

        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Login", TitledBorder.CENTER, TitledBorder.TOP));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel studentIdLabel = new JLabel("Student ID:");
        studentIdField = new JTextField(15);
        setupHint(studentIdField, "Enter Student ID");

        JLabel passLabel = new JLabel("Password:");
        passField = new JPasswordField(15);
        setupPasswordHint(passField, "Enter Password");

        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                passField.setEchoChar(showPasswordCheckBox.isSelected() ? (char) 0 : '*');
            }
        });

        forgotPasswordButton = new JButton("Forgot Password?");
        forgotPasswordButton.setBorderPainted(false);
        forgotPasswordButton.setContentAreaFilled(false);
        forgotPasswordButton.setForeground(Color.BLUE);
        forgotPasswordButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgotPasswordButton.setToolTipText("Recover your password via email");
        forgotPasswordButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ForgotPassword();
            }
        });

        final JButton themeToggleButton = new JButton("Dark Mode");
        themeToggleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isDarkTheme = !isDarkTheme;
                applyTheme(isDarkTheme);
                themeToggleButton.setText(isDarkTheme ? "Light Mode" : "Dark Mode");
            }
        });

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registerStudent();
            }
        });

        gbc.gridx = 0; gbc.gridy = 0; loginPanel.add(studentIdLabel, gbc);
        gbc.gridx = 1; loginPanel.add(studentIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; loginPanel.add(passLabel, gbc);
        gbc.gridx = 1; loginPanel.add(passField, gbc);

        JPanel optionsPanel = new JPanel(new BorderLayout());
        optionsPanel.add(showPasswordCheckBox, BorderLayout.WEST);
        optionsPanel.add(forgotPasswordButton, BorderLayout.EAST);
        gbc.gridx = 1; gbc.gridy = 2; loginPanel.add(optionsPanel, gbc);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        actionPanel.add(loginButton);
        actionPanel.add(registerButton);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        loginPanel.add(actionPanel, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        loginPanel.add(themeToggleButton, gbc);

        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        frame.add(loginPanel, gbcMain);

        // Java 1.6-compatible invokeLater
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                studentIdField.requestFocusInWindow();
            }
        });

        frame.setVisible(true);
    }

    private void setupHint(final JTextField field, final String hint) {
        field.setForeground(Color.GRAY);
        field.setText(hint);

        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(hint)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(hint);
                    field.setForeground(Color.GRAY);
                }
            }
        });
    }

    private void setupPasswordHint(final JPasswordField field, final String hint) {
        field.setEchoChar((char) 0);
        field.setForeground(Color.GRAY);
        field.setText(hint);

        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (String.valueOf(field.getPassword()).equals(hint)) {
                    field.setText("");
                    field.setEchoChar('*');
                    field.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (String.valueOf(field.getPassword()).isEmpty()) {
                    field.setText(hint);
                    field.setEchoChar((char) 0);
                    field.setForeground(Color.GRAY);
                }
            }
        });
    }

    private void applyTheme(boolean dark) {
        Color bg = dark ? new Color(45, 45, 45) : UIManager.getColor("Panel.background");
        Color fg = dark ? Color.WHITE : Color.BLACK;
        frame.getContentPane().setBackground(bg);
        Component[] comps = frame.getContentPane().getComponents();
        for (int i = 0; i < comps.length; i++) {
            setComponentTheme(comps[i], bg, fg);
        }
        frame.repaint();
    }

    private void setComponentTheme(Component c, Color bg, Color fg) {
        c.setBackground(bg);
        c.setForeground(fg);
        if (c instanceof JPanel) {
            Component[] subs = ((JPanel) c).getComponents();
            for (int i = 0; i < subs.length; i++) {
                setComponentTheme(subs[i], bg, fg);
            }
        }
    }

    private void handleLogin() {
        String studentId = studentIdField.getText().trim();
        String password = new String(passField.getPassword());

        if (studentId.isEmpty() || password.isEmpty() || password.equals("Enter Password")) {
            JOptionPane.showMessageDialog(frame, "Please enter both Student ID and Password!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String fullName = authenticateStudent(studentId, password);
        if (fullName != null) {
            JOptionPane.showMessageDialog(frame, "Welcome, " + fullName + "!");
            frame.dispose();
            new StudentPanel(Integer.parseInt(studentId), fullName);
        }
    }

    private void registerStudent() {
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        Object[] message = {
                "Full Name:", nameField,
                "Email:", emailField,
                "Password:", passwordField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Register New Student", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim().toLowerCase();
            String password = new String(passwordField.getPassword()).trim();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!isValidEmail(email)) {
                JOptionPane.showMessageDialog(frame, "Invalid email format!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Connection con = null;
            PreparedStatement pst = null;
            ResultSet rs = null;

            try {
                con = DatabaseConnection.getConnection();
                pst = con.prepareStatement("SELECT COUNT(*) FROM Student WHERE Email = ?");
                pst.setString(1, email);
                rs = pst.executeQuery();

                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(frame, "An account with this email already exists!", "Duplicate Email", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                pst.close();
                rs.close();

                pst = con.prepareStatement("INSERT INTO Student (FullName, Email, Password) VALUES (?, ?, ?)");
                pst.setString(1, name);
                pst.setString(2, email);
                pst.setString(3, password);

                if (pst.executeUpdate() > 0) {
                    pst.close();
                    pst = con.prepareStatement("SELECT MAX(StudentID) AS LastID FROM Student");
                    rs = pst.executeQuery();

                    if (rs.next()) {
                        int studentId = rs.getInt("LastID");
                        JOptionPane.showMessageDialog(frame, "Registration successful!\nYour Student ID is: " + studentId);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Registration failed.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error during registration.", "Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                close(pst, rs);
                DatabaseConnection.closeConnection(con);
            }
        }
    }

    private String authenticateStudent(String studentId, String password) {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.getConnection();
            pst = con.prepareStatement("SELECT FullName, Password FROM Student WHERE StudentID = ?");
            pst.setString(1, studentId);
            rs = pst.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(frame, "Invalid Student ID!", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }

            String dbPassword = rs.getString("Password");
            if (dbPassword.equals(password)) {
                return rs.getString("FullName");
            } else {
                JOptionPane.showMessageDialog(frame, "Incorrect Password!", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(pst, rs);
            DatabaseConnection.closeConnection(con);
        }
        return null;
    }

    private boolean isValidEmail(String email) {
        return Pattern.matches("^[\\w.-]+@[\\w.-]+\\.\\w+$", email);
    }

    private void close(PreparedStatement pst, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
        } catch (Exception ignored) {}
    }

    public static void main(String[] args) {
        new StudentLogin();
    }
}
