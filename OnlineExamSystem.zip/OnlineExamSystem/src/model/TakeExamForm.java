package model;

import database.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;

public class TakeExamForm {
    private JFrame frame;
    private Map<Integer, JRadioButton> selectedAnswers;
    private Map<Integer, String> correctAnswers;
    private int studentID;
    private int examID;
    private Timer countdownTimer;
    private int remainingTimeInSeconds;
    private List<Integer> questionOrder = new ArrayList<Integer>(); // Keeps track of display order

    private JLabel timerLabel;

    public TakeExamForm(int studentID, int examID) {
        this.studentID = studentID;
        this.examID = examID;

        frame = new JFrame("Take Exam");
        frame.setSize(600, 700);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 1));

        selectedAnswers = new HashMap<>();
        correctAnswers = new HashMap<>();

        timerLabel = new JLabel("Time Left: 30:00", SwingConstants.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        frame.add(timerLabel);

        loadQuestions();

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            if (countdownTimer != null) {
                countdownTimer.stop();
            }
            evaluateExam();
        });

        frame.add(submitButton);
        frame.setVisible(true);

loadExamDuration();
startTimer();
    }

private void loadQuestions() {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        con = DatabaseConnection.getConnection();
        if (con == null) {
            JOptionPane.showMessageDialog(frame, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String query = "SELECT * FROM Question WHERE ExamID=?";
        pst = con.prepareStatement(query);
        pst.setInt(1, examID);
        rs = pst.executeQuery();

        List<Map<String, String>> questions = new ArrayList<Map<String, String>>();

        while (rs.next()) {
            Map<String, String> q = new HashMap<String, String>();
            q.put("id", String.valueOf(rs.getInt("QuestionID")));
            q.put("text", rs.getString("QuestionText"));
            q.put("a", rs.getString("OptionA"));
            q.put("b", rs.getString("OptionB"));
            q.put("c", rs.getString("OptionC"));
            q.put("d", rs.getString("OptionD"));
            q.put("correct", rs.getString("CorrectAnswer"));
            questions.add(q);
        }

        Collections.shuffle(questions); // Optional: for random order

        int srNo = 1;
        for (Map<String, String> q : questions) {
            int qID = Integer.parseInt(q.get("id"));
            correctAnswers.put(qID, q.get("correct"));
            questionOrder.add(qID); 

            JLabel questionLabel = new JLabel("Q" + srNo + ": " + q.get("text"));
            srNo++; // increment for next question

            JRadioButton optionA = new JRadioButton("A) " + q.get("a"));
            JRadioButton optionB = new JRadioButton("B) " + q.get("b"));
            JRadioButton optionC = new JRadioButton("C) " + q.get("c"));
            JRadioButton optionD = new JRadioButton("D) " + q.get("d"));

            ButtonGroup group = new ButtonGroup();
            group.add(optionA);
            group.add(optionB);
            group.add(optionC);
            group.add(optionD);

            final int questionKey = qID; // for use in inner class
            ActionListener answerListener = new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    selectedAnswers.put(questionKey, (JRadioButton) e.getSource());
                }
            };

            optionA.addActionListener(answerListener);
            optionB.addActionListener(answerListener);
            optionC.addActionListener(answerListener);
            optionD.addActionListener(answerListener);

            frame.add(questionLabel);
            frame.add(optionA);
            frame.add(optionB);
            frame.add(optionC);
            frame.add(optionD);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try { if (rs != null) rs.close(); } catch (SQLException ex) {}
        try { if (pst != null) pst.close(); } catch (SQLException ex) {}
        DatabaseConnection.closeConnection(con);
    }
}

private void evaluateExam() {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    int score = 0;

    try {
        con = DatabaseConnection.getConnection();

        for (Map.Entry<Integer, String> entry : correctAnswers.entrySet()) {
            int questionID = entry.getKey();
            String correct = entry.getValue();
            String selected = selectedAnswers.containsKey(questionID)
                    ? selectedAnswers.get(questionID).getText().substring(0, 1)
                    : "None";

            if (selected.equalsIgnoreCase(correct)) {
                ps = con.prepareStatement("SELECT Marks FROM Question WHERE QuestionID = ?");
                ps.setInt(1, questionID);
                rs = ps.executeQuery();
                if (rs.next()) {
                    score += rs.getInt("Marks");
                }
                rs.close();
                ps.close();
            }
        }

        ps = con.prepareStatement("INSERT INTO Result (StudentID, ExamID, Score) VALUES (?, ?, ?)");
        ps.setInt(1, studentID);
        ps.setInt(2, examID);
        ps.setInt(3, score);
        ps.executeUpdate();
        ps.close();

        JOptionPane.showMessageDialog(frame, "Exam Completed! Your score: " + score, "Result", JOptionPane.INFORMATION_MESSAGE);
        frame.dispose();
        showReviewPanel();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        try { if (rs != null) rs.close(); if (ps != null) ps.close(); } catch (Exception e) {}
        DatabaseConnection.closeConnection(con);
    }
}



    private void loadExamDuration() {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        con = DatabaseConnection.getConnection();
        pst = con.prepareStatement("SELECT Duration FROM Exam WHERE ExamID = ?");
        pst.setInt(1, examID);
        rs = pst.executeQuery();

        if (rs.next()) {
            int durationMinutes = rs.getInt("Duration");
            remainingTimeInSeconds = durationMinutes * 60;
        } else {
            remainingTimeInSeconds = 1800; // fallback default
        }
    } catch (Exception e) {
        remainingTimeInSeconds = 1800;
        e.printStackTrace();
    } finally {
        try { if (rs != null) rs.close(); } catch (Exception e) {}
        try { if (pst != null) pst.close(); } catch (Exception e) {}
        DatabaseConnection.closeConnection(con);
    }
}


    private void startTimer() {
        countdownTimer = new Timer(1000, e -> {
            int minutes = remainingTimeInSeconds / 60;
            int seconds = remainingTimeInSeconds % 60;
            timerLabel.setText("Time Left: " + String.format("%02d:%02d", minutes, seconds));
            remainingTimeInSeconds--;

            if (remainingTimeInSeconds < 0) {
                countdownTimer.stop();
                JOptionPane.showMessageDialog(frame, "Time is up! Submitting your exam.");
                evaluateExam();
            }
        });
        countdownTimer.start();
    }

private void showReviewPanel() {
    JFrame reviewFrame = new JFrame("Review Answers");
    reviewFrame.setSize(600, 600);
    reviewFrame.setLayout(new GridLayout(0, 1));

    int srNo = 1;
    for (int questionID : questionOrder) {
        String correct = correctAnswers.get(questionID);
        String selected = selectedAnswers.containsKey(questionID)
                ? selectedAnswers.get(questionID).getText().substring(0, 1)
                : "None";

        String result = selected.equalsIgnoreCase(correct) ? "✅ Correct" : "❌ Incorrect";

        reviewFrame.add(new JLabel("Q" + srNo + ": Your Answer: " + selected +
                ", Correct: " + correct + " — " + result));
        srNo++;
    }

    reviewFrame.setVisible(true);
}


    public static void main(String[] args) {
        new TakeExamForm(1, 1); // Test with dummy IDs
    }
}
