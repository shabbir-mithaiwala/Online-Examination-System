package ui;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.List;
import database.DatabaseConnection;

public class AssignExamForm extends JFrame {
    private JTextField searchField, examSearchField;
    private JTable studentTable;
    private DefaultTableModel studentTableModel;
    private JPanel examsPanel;
    private List<JCheckBox> examCheckBoxes = new ArrayList<>();
    private JButton assignBtn, unassignBtn, viewAssignedBtn;
    private JComboBox<String> categoryFilterCombo = new JComboBox<>();
    private Map<Integer, String> examMap = new LinkedHashMap<>();
    private int selectedStudentId = -1;

    public AssignExamForm() {
        setTitle("Assign Exams to Students");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // === LEFT SIDE ===
        var studentPanel = new JPanel(new BorderLayout());
        var searchPanel = new JPanel(new BorderLayout());
        searchField = new JTextField();
        searchPanel.add(new JLabel("Search Student: "), BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        studentPanel.add(searchPanel, BorderLayout.NORTH);

        studentTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Email"}, 0);
        studentTable = new JTable(studentTableModel);
        studentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentPanel.add(new JScrollPane(studentTable), BorderLayout.CENTER);
        add(studentPanel, BorderLayout.WEST);

        // === RIGHT SIDE ===
        var rightPanel = new JPanel(new BorderLayout());
        var examSearchPanel = new JPanel(new BorderLayout());
        examSearchField = new JTextField();
        examSearchPanel.add(new JLabel("Search Exam: "), BorderLayout.WEST);
        examSearchPanel.add(examSearchField, BorderLayout.CENTER);
        rightPanel.add(examSearchPanel, BorderLayout.NORTH);

        var categoryPanel = new JPanel(new BorderLayout());
        categoryPanel.add(new JLabel("Filter by Category: "), BorderLayout.WEST);
        categoryPanel.add(categoryFilterCombo, BorderLayout.CENTER);
        rightPanel.add(categoryPanel, BorderLayout.BEFORE_FIRST_LINE);

        examsPanel = new JPanel();
        examsPanel.setLayout(new BoxLayout(examsPanel, BoxLayout.Y_AXIS));
        rightPanel.add(new JScrollPane(examsPanel), BorderLayout.CENTER);

        var buttonPanel = new JPanel(new FlowLayout());
        assignBtn = new JButton("Assign");
        unassignBtn = new JButton("Unassign");
        viewAssignedBtn = new JButton("View Assigned");
        buttonPanel.add(assignBtn);
        buttonPanel.add(unassignBtn);
        buttonPanel.add(viewAssignedBtn);
        rightPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(rightPanel, BorderLayout.CENTER);

        loadStudents();
        loadExams();
        loadCategories();

        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterStudents();
            }
        });

        examSearchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterExams();
            }
        });

        studentTable.getSelectionModel().addListSelectionListener(e -> {
            int row = studentTable.getSelectedRow();
            if (row != -1) {
                int modelRow = studentTable.convertRowIndexToModel(row);
                selectedStudentId = Integer.parseInt(studentTableModel.getValueAt(modelRow, 0).toString());
                updateExamCheckboxStates();
            }
        });

        assignBtn.addActionListener(e -> assignSelectedExams());
        unassignBtn.addActionListener(e -> unassignSelectedExams());
        viewAssignedBtn.addActionListener(e -> showAllAssignedExamsTable());
        categoryFilterCombo.addActionListener(e -> filterExams());

        setVisible(true);
    }

    private void showAllAssignedExamsTable() {
        var dialog = new JDialog(this, "Assigned Exams Overview", true);
        dialog.setSize(750, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        var model = new DefaultTableModel();
        var table = new JTable(model);
        var scrollPane = new JScrollPane(table);

        var searchField = new JTextField();
        var topPanel = new JPanel(new BorderLayout());
        topPanel.add(new JLabel("Search: "), BorderLayout.WEST);
        topPanel.add(searchField, BorderLayout.CENTER);

        try (var con = DatabaseConnection.getConnection();
             var ps = con.prepareStatement("""
                    SELECT s.StudentID, s.FullName, e.ExamID, e.ExamName, e.Category 
                    FROM (AssignedExams ae 
                    INNER JOIN Student s ON ae.StudentID = s.StudentID) 
                    INNER JOIN Exam e ON ae.ExamID = e.ExamID""",
                 ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_READ_ONLY);
             var rs = ps.executeQuery()) {

            boolean showNames = true;
            while (rs.next()) {
                if ((rs.getString("FullName") != null && rs.getString("FullName").length() > 30)
                        || (rs.getString("ExamName") != null && rs.getString("ExamName").length() > 30)) {
                    showNames = false;
                    break;
                }
            }
            rs.beforeFirst();

            model.addColumn("Student ID");
            if (showNames) model.addColumn("Student Name");
            model.addColumn("Exam ID");
            if (showNames) model.addColumn("Exam Name");
            model.addColumn("Category");

            while (rs.next()) {
                var row = new Vector<Object>();
                row.add(rs.getInt("StudentID"));
                if (showNames) row.add(rs.getString("FullName"));
                row.add(rs.getInt("ExamID"));
                if (showNames) row.add(rs.getString("ExamName"));
                row.add(rs.getString("Category"));
                model.addRow(row);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data.");
            return;
        }

        var sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filter(); }
            public void removeUpdate(DocumentEvent e) { filter(); }
            public void changedUpdate(DocumentEvent e) { filter(); }

            private void filter() {
                var keyword = searchField.getText();
                try {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + keyword));
                } catch (Exception e) {
                    sorter.setRowFilter(null);
                }
            }
        });

        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void loadCategories() {
        categoryFilterCombo.removeAllItems();
        categoryFilterCombo.addItem("All");

        try (var con = DatabaseConnection.getConnection();
             var stmt = con.createStatement();
             var rs = stmt.executeQuery("SELECT DISTINCT Category FROM Exam WHERE Category IS NOT NULL AND TRIM(Category) <> ''")) {
            while (rs.next()) {
                var category = rs.getString("Category");
                if (category != null && !category.trim().isEmpty()) {
                    categoryFilterCombo.addItem(category.trim());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load categories.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadStudents() {
        studentTableModel.setRowCount(0);
        try (var con = DatabaseConnection.getConnection();
             var stmt = con.createStatement();
             var rs = stmt.executeQuery("SELECT StudentID, FullName, Email FROM Student")) {

            while (rs.next()) {
                studentTableModel.addRow(new Object[]{
                        rs.getInt("StudentID"),
                        rs.getString("FullName"),
                        rs.getString("Email")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void loadExams() {
        examMap.clear();
        examCheckBoxes.clear();
        examsPanel.removeAll();

        try (var con = DatabaseConnection.getConnection();
             var stmt = con.createStatement();
             var rs = stmt.executeQuery("SELECT ExamID, ExamName FROM Exam")) {

            while (rs.next()) {
                examMap.put(rs.getInt("ExamID"), rs.getString("ExamName"));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        refreshExamCheckboxes("");
    }

    private void refreshExamCheckboxes(String keyword) {
        examsPanel.removeAll();
        examCheckBoxes.clear();

        var selectedCategory = (String) categoryFilterCombo.getSelectedItem();
        if ("All".equalsIgnoreCase(selectedCategory)) selectedCategory = null;

        for (var entry : examMap.entrySet()) {
            var examId = entry.getKey();
            var examName = entry.getValue();
            var category = getExamCategoryById(examId);

            var matchesCategory = (selectedCategory == null || category != null && category.equalsIgnoreCase(selectedCategory));
            var matchesKeyword = (keyword == null || examName.toLowerCase().contains(keyword.toLowerCase()));

            if (matchesCategory && matchesKeyword) {
                var cb = new JCheckBox(examName);
                examsPanel.add(cb);
                examCheckBoxes.add(cb);
            }
        }

        examsPanel.revalidate();
        examsPanel.repaint();
        updateExamCheckboxStates();
    }

    private String getExamCategoryById(int examId) {
        try (var con = DatabaseConnection.getConnection();
             var ps = con.prepareStatement("SELECT Category FROM Exam WHERE ExamID = ?")) {
            ps.setInt(1, examId);
            try (var rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("Category") : null;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    private void updateExamCheckboxStates() {
        if (selectedStudentId == -1) return;

        try (var con = DatabaseConnection.getConnection();
             var ps = con.prepareStatement("SELECT ExamID FROM AssignedExams WHERE StudentID = ?")) {
            ps.setInt(1, selectedStudentId);

            try (var rs = ps.executeQuery()) {
                var assigned = new HashSet<Integer>();
                while (rs.next()) {
                    assigned.add(rs.getInt("ExamID"));
                }

                for (var cb : examCheckBoxes) {
                    int examId = getExamIdByName(cb.getText());
                    if (assigned.contains(examId)) {
                        cb.setSelected(true);
                        cb.setForeground(Color.GRAY);
                        cb.setToolTipText("Already assigned");
                    } else {
                        cb.setSelected(false);
                        cb.setForeground(Color.BLACK);
                        cb.setToolTipText("Not assigned");
                        cb.setEnabled(true);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private int getExamIdByName(String name) {
        for (var entry : examMap.entrySet()) {
            if (entry.getValue().equals(name)) {
                return entry.getKey();
            }
        }
        return -1;
    }

    private boolean alreadyAssigned(Connection con, int studentId, int examId) throws SQLException {
        try (var ps = con.prepareStatement("SELECT * FROM AssignedExams WHERE StudentID=? AND ExamID=?")) {
            ps.setInt(1, studentId);
            ps.setInt(2, examId);
            try (var rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private void assignSelectedExams() {
        if (selectedStudentId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a student first.");
            return;
        }

        try (var con = DatabaseConnection.getConnection();
             var ps = con.prepareStatement("INSERT INTO AssignedExams (StudentID, ExamID) VALUES (?, ?)")) {

            int assigned = 0, skipped = 0;
            for (var cb : examCheckBoxes) {
                if (cb.isSelected()) {
                    int examId = getExamIdByName(cb.getText());
                    if (!alreadyAssigned(con, selectedStudentId, examId)) {
                        ps.setInt(1, selectedStudentId);
                        ps.setInt(2, examId);
                        ps.executeUpdate();
                        assigned++;
                    } else {
                        skipped++;
                    }
                }
            }

            JOptionPane.showMessageDialog(this, assigned + " exam(s) assigned. " + skipped + " skipped.");
            updateExamCheckboxStates();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void unassignSelectedExams() {
        if (selectedStudentId == -1) {
            JOptionPane.showMessageDialog(this, "Please select a student first.");
            return;
        }

        try (var con = DatabaseConnection.getConnection();
             var ps = con.prepareStatement("DELETE FROM AssignedExams WHERE StudentID = ? AND ExamID = ?")) {

            int count = 0;
            for (var cb : examCheckBoxes) {
                if (!cb.isSelected()) {
                    int examId = getExamIdByName(cb.getText());
                    ps.setInt(1, selectedStudentId);
                    ps.setInt(2, examId);
                    if (ps.executeUpdate() > 0) count++;
                }
            }

            JOptionPane.showMessageDialog(this, count + " exam(s) unassigned.");
            updateExamCheckboxStates();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void filterStudents() {
        var keyword = searchField.getText().toLowerCase();
        var sorter = new TableRowSorter<>(studentTableModel);
        studentTable.setRowSorter(sorter);
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + keyword));
    }

    private void filterExams() {
        var keyword = examSearchField.getText().toLowerCase();
        refreshExamCheckboxes(keyword);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AssignExamForm::new);
    }
}
