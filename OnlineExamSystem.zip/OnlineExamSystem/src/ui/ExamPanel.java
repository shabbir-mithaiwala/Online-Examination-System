package ui;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import database.DatabaseConnection;
import model.Question;

public class ExamPanel extends JFrame {
    private final int studentId;
    private final int examId;
    private final List<Question> questions = new ArrayList<>();
    private final Map<Integer, String> answers = new HashMap<>();
    private int currentIndex = 0;
    private int timeLeft = 60;

    private JLabel lblQuestion, lblTimer;
    private final JRadioButton[] options = new JRadioButton[4];
    private JButton btnNext, btnSubmit;
    private ButtonGroup optionGroup;
    private Timer timer;

    public ExamPanel(int studentId, int examId) {
        this.studentId = studentId;
        this.examId = examId;

        setTitle("Exam Panel");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(7, 1));

        lblTimer = new JLabel("Time Left: 60s");
        lblQuestion = new JLabel("Question");
        add(lblTimer);
        add(lblQuestion);

        optionGroup = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            options[i] = new JRadioButton();
            optionGroup.add(options[i]);
            add(options[i]);
        }

        btnNext = new JButton("Next");
        btnSubmit = new JButton("Submit");
        add(btnNext);
        add(btnSubmit);

        btnNext.addActionListener(e -> {
            recordAnswer();
            currentIndex++;
            if (currentIndex < questions.size()) {
                showQuestion(currentIndex);
            } else {
                JOptionPane.showMessageDialog(this, "No more questions. Please submit.");
            }
        });

        btnSubmit.addActionListener(e -> {
            recordAnswer();
            submitExam();
        });

        loadQuestions();
        startTimer();
        setVisible(true);
    }

    private void loadQuestions() {
        try (var conn = DatabaseConnection.getConnection();
             var stmt = conn.prepareStatement("SELECT * FROM Question WHERE exam_id = ?")) {
            stmt.setInt(1, examId);
            try (var rs = stmt.executeQuery()) {
                while (rs.next()) {
                    var question = new Question(
                        rs.getInt("id"),
                        rs.getInt("exam_id"),
                        rs.getString("question"),
                        rs.getString("option1"),
                        rs.getString("option2"),
                        rs.getString("option3"),
                        rs.getString("option4"),
                        rs.getString("correct_answer")
                    );
                    questions.add(question);
                }
            }

            if (!questions.isEmpty()) {
                showQuestion(currentIndex);
            } else {
                JOptionPane.showMessageDialog(this, "No questions found!");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load questions.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showQuestion(int index) {
        var q = questions.get(index);
        lblQuestion.setText("Q" + (index + 1) + ": " + q.getQuestion());
        options[0].setText(q.getOption1());
        options[1].setText(q.getOption2());
        options[2].setText(q.getOption3());
        options[3].setText(q.getOption4());

        optionGroup.clearSelection();
        var prevAnswer = answers.get(q.getId());
        if (prevAnswer != null) {
            for (var option : options) {
                if (option.getText().equals(prevAnswer)) {
                    option.setSelected(true);
                    break;
                }
            }
        }
    }

    private void recordAnswer() {
        var q = questions.get(currentIndex);
        for (var option : options) {
            if (option.isSelected()) {
                answers.put(q.getId(), option.getText());
                break;
            }
        }
    }

    private void startTimer() {
        timer = new Timer(1000, e -> {
            timeLeft--;
            lblTimer.setText("Time Left: " + timeLeft + "s");
            if (timeLeft <= 0) {
                timer.stop();
                JOptionPane.showMessageDialog(this, "Time's up! Submitting your exam.");
                recordAnswer();
                submitExam();
            }
        });
        timer.start();
    }

    private void submitExam() {
        if (timer != null) timer.stop();

        int score = 0;
        for (var q : questions) {
            var selected = answers.get(q.getId());
            if (selected != null && selected.equals(q.getCorrectAnswer())) {
                score++;
            }
        }

        try (var conn = DatabaseConnection.getConnection();
             var stmt = conn.prepareStatement(
                     "INSERT INTO Result(student_id, exam_id, score) VALUES (?, ?, ?)")) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, examId);
            stmt.setInt(3, score);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Exam Submitted! Your score is: " + score);
            dispose();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error submitting exam.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Example usage
        SwingUtilities.invokeLater(() -> new ExamPanel(1, 101)); // Replace with actual student & exam ID
    }
}
