package ui;

import database.DatabaseConnection;
import model.TakeExamForm;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentPanel {
    private JFrame frame;
    private JTabbedPane tabbedPane;
    private JTable examTable, resultTable;
    private DefaultTableModel examModel, resultModel;
    private JButton refreshButton, logoutButton, themeToggleButton;
    private JLabel statusBar;
    private int studentID;
    private javax.swing.Timer refreshTimer;
    private boolean isDarkMode = false;
    private JProgressBar progressBar;

    public StudentPanel(final int studentID, String fullName) {
        this.studentID = studentID;
        frame = new JFrame("Student Panel - " + fullName + " (ID: " + studentID + ")");
        frame.setSize(700, 550);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        tabbedPane = new JTabbedPane();
        statusBar = new JLabel("Welcome!");

        // --- Top Bar with Buttons ---
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshButton = new JButton("Refresh");
        logoutButton = new JButton("Logout");
        themeToggleButton = new JButton("Light Mode");

        topPanel.add(refreshButton);
        topPanel.add(themeToggleButton);
        topPanel.add(logoutButton);
        frame.add(topPanel, BorderLayout.NORTH);

        // --- Exams Tab ---
        JPanel examPanel = new JPanel(new BorderLayout());
        examModel = new DefaultTableModel(new String[]{"Exam Name", "Status", "Action"}, 0) {
            public boolean isCellEditable(int row, int col) {
                return col == 2;
            }
        };
        examTable = new JTable(examModel);
        examTable.getColumn("Action").setCellRenderer(new ButtonRenderer());
        examTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox()));
        JScrollPane examScrollPane = new JScrollPane(examTable);

        examPanel.add(examScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Assigned Exams", examPanel);

        // --- Results Tab ---
        JPanel resultPanel = new JPanel(new BorderLayout());
        resultModel = new DefaultTableModel(new String[]{"Exam", "Score", "Grade", "Status"}, 0);
        resultTable = new JTable(resultModel);
        JScrollPane resultScrollPane = new JScrollPane(resultTable);

        progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);

        resultPanel.add(progressBar, BorderLayout.NORTH);
        resultPanel.add(resultScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Results", resultPanel);

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.add(statusBar, BorderLayout.SOUTH);
        frame.setVisible(true);

        loadAssignedExams();
        loadResults();

        refreshTimer = new javax.swing.Timer(60000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadAssignedExams();
                loadResults();
            }
        });
        refreshTimer.start();

        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadAssignedExams();
                loadResults();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    frame.dispose();
                    new model.StudentLogin(); // back to login
                }
            }
        });

        themeToggleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isDarkMode = !isDarkMode;
                updateTheme();
            }
        });
    }

private void updateTheme() {
    Color bg = isDarkMode ? Color.DARK_GRAY : UIManager.getColor("Panel.background");
    Color fg = isDarkMode ? Color.WHITE : Color.BLACK;
    Color buttonBg = isDarkMode ? Color.BLACK : Color.WHITE;
    Color buttonFg = isDarkMode ? Color.WHITE : Color.BLACK;

    // Manually updating the background and foreground for each component
    frame.getContentPane().setBackground(bg);
    tabbedPane.setBackground(bg);
    tabbedPane.setForeground(fg);
    themeToggleButton.setText(isDarkMode ? "Light Mode" : "Dark Mode");
    themeToggleButton.setBackground(buttonBg);
    themeToggleButton.setForeground(buttonFg);
    refreshButton.setBackground(buttonBg);
    refreshButton.setForeground(buttonFg);
    logoutButton.setBackground(buttonBg);
    logoutButton.setForeground(buttonFg);

    examTable.setBackground(isDarkMode ? Color.DARK_GRAY : Color.WHITE);
    examTable.setForeground(fg);
    resultTable.setBackground(isDarkMode ? Color.DARK_GRAY : Color.WHITE);
    resultTable.setForeground(fg);

    progressBar.setBackground(isDarkMode ? Color.DARK_GRAY : Color.WHITE);
    progressBar.setForeground(fg);

    statusBar.setForeground(fg);

    // Revalidate and repaint the components that need updates
    tabbedPane.revalidate();
    tabbedPane.repaint();
    examTable.revalidate();
    examTable.repaint();
    resultTable.revalidate();
    resultTable.repaint();
}


    private void loadAssignedExams() {
        examModel.setRowCount(0);
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.getConnection();
            String sql = "SELECT E.ExamID, E.ExamName, " +
                         "IIf(r.Score IS NULL, 'Assigned', 'Completed') AS Status " +
                         "FROM (AssignedExams AS AE INNER JOIN Exam AS E ON AE.ExamID = E.ExamID) " +
                         "LEFT JOIN Result AS r ON AE.ExamID = r.ExamID AND AE.StudentID = r.StudentID " +
                         "WHERE AE.StudentID = ?";
            pst = con.prepareStatement(sql);
            pst.setInt(1, studentID);
            rs = pst.executeQuery();

            while (rs.next()) {
                int examID = rs.getInt("ExamID");
                String examName = rs.getString("ExamName");
                String status = rs.getString("Status");
                String action = "Assigned".equals(status) ? "Start" : "View";
                examModel.addRow(new Object[]{examName, status, action});
            }
            statusBar.setText("Assigned exams loaded.");
        } catch (Exception ex) {
            ex.printStackTrace();
            statusBar.setText("Error loading exams.");
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
            } catch (Exception ex) {}
            DatabaseConnection.closeConnection(con);
        }
    }

    private void loadResults() {
    resultModel.setRowCount(0);
    progressBar.setVisible(true);
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        con = DatabaseConnection.getConnection();
        pst = con.prepareStatement(
            "SELECT e.ExamID, e.ExamName, r.Score, " +
            "(SELECT SUM(Marks) FROM Question q WHERE q.ExamID = e.ExamID) AS TotalMarks " +
            "FROM Result r INNER JOIN Exam e ON r.ExamID = e.ExamID " +
            "WHERE r.StudentID = ?");
        pst.setInt(1, studentID);
        rs = pst.executeQuery();

        while (rs.next()) {
            String examName = rs.getString("ExamName");
            int score = rs.getInt("Score");
            int totalMarks = rs.getInt("TotalMarks");

            double percentage = (totalMarks > 0) ? ((double) score / totalMarks) * 100 : 0;

            String grade = (percentage >= 90) ? "A+" :
                           (percentage >= 75) ? "A" :
                           (percentage >= 60) ? "B" :
                           (percentage >= 40) ? "C" : "F";

            String status = (percentage >= 40) ? "Pass" : "Fail";

            resultModel.addRow(new Object[]{examName, score + "/" + totalMarks, grade, status});
        }

        statusBar.setText("Results loaded.");
    } catch (Exception ex) {
        ex.printStackTrace();
        statusBar.setText("Error loading results.");
    } finally {
        try { if (rs != null) rs.close(); if (pst != null) pst.close(); } catch (Exception ex) {}
        DatabaseConnection.closeConnection(con);
        progressBar.setVisible(false);
    }
}




    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);

            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    int selectedRow = examTable.getSelectedRow();
                    String examName = (String) examModel.getValueAt(selectedRow, 0);
                    String status = (String) examModel.getValueAt(selectedRow, 1);
                    int examID = getExamIDByName(examName);
                    if ("Start".equals(label) && "Assigned".equals(status)) {
                        new TakeExamForm(studentID, examID);
                    } else if ("View".equals(label)) {
                        JOptionPane.showMessageDialog(frame, "You have already completed this exam.");
                    }
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            return button;
        }

        public Object getCellEditorValue() {
            return label;
        }
    }

    private int getExamIDByName(String examName) {
        int id = -1;
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.getConnection();
            pst = con.prepareStatement("SELECT ExamID FROM Exam WHERE ExamName = ?");
            pst.setString(1, examName);
            rs = pst.executeQuery();
            if (rs.next()) {
                id = rs.getInt("ExamID");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); if (pst != null) pst.close(); } catch (Exception ex) {}
            DatabaseConnection.closeConnection(con);
        }

        return id;
    }

    public static void main(String[] args) {
        new StudentPanel(1, "John Doe"); // Replace with dynamic name later
    }
}
