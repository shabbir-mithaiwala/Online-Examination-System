package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import database.DatabaseConnection;

public class QuestionManager extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtQuestionText, txtOptionA, txtOptionB, txtOptionC, txtOptionD, txtSearch, txtMarks;
    private JComboBox<String> comboCorrectAnswer, comboExamDropdown, comboExamFilter;
    private JLabel lblCharCount, lblPageInfo, lblTotalInfo;
    private JButton btnAdd, btnUpdate, btnDelete, btnClear, btnFirst, btnPrev, btnNext, btnLast;
    
    private JToggleButton themeToggle;
    private boolean isDarkMode = false;

    private List<Object[]> allRows = new ArrayList<>();
    private int currentPage = 1;
    private final int pageSize = 5;
    private Integer lastSelectedId = null;

    private Map<String, Integer> examMap = new HashMap<>();

    public QuestionManager() {
        setTitle("Question Manager");
        setSize(1050, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        initComponents();
        applyTheme();

        loadExams();
        loadQuestionsFromDatabase();
        setVisible(true);
    }

    private void initComponents() {
        model = new DefaultTableModel(new String[]{"ID", "Exam", "Question", "A", "B", "C", "D", "Correct", "Marks"}, 0);

        table = new JTable(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setAutoCreateRowSorter(true);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        comboExamDropdown = new JComboBox<>();
        txtQuestionText = new JTextField(20);
        txtOptionA = new JTextField(20);
        txtOptionB = new JTextField(20);
        txtOptionC = new JTextField(20);
        txtOptionD = new JTextField(20);
        comboCorrectAnswer = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        lblCharCount = new JLabel("0 / 500");
        txtMarks = new JTextField(5);

        int row = 0;
        addFormField(formPanel, gbc, row++, "Exam:", comboExamDropdown);
        addFormField(formPanel, gbc, row++, "Question:", txtQuestionText);
        addFormField(formPanel, gbc, row++, "", lblCharCount);
        addFormField(formPanel, gbc, row++, "Option A:", txtOptionA);
        addFormField(formPanel, gbc, row++, "Option B:", txtOptionB);
        addFormField(formPanel, gbc, row++, "Option C:", txtOptionC);
        addFormField(formPanel, gbc, row++, "Option D:", txtOptionD);
        addFormField(formPanel, gbc, row++, "Correct Answer:", comboCorrectAnswer);
        addFormField(formPanel, gbc, row++, "Marks:", txtMarks);

        JPanel buttonPanel = new JPanel();
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnClear = new JButton("Clear");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnClear);

        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonPanel, gbc);

        JPanel westPanel = new JPanel(new BorderLayout());
        westPanel.add(formPanel, BorderLayout.NORTH);
        add(westPanel, BorderLayout.WEST);

        JPanel paginationPanel = new JPanel();
        btnFirst = new JButton("<<");
        btnPrev = new JButton("<");
        lblPageInfo = new JLabel("Page 1");
        lblTotalInfo = new JLabel("Total: 0 questions");
        btnNext = new JButton(">");
        btnLast = new JButton(">>");

        paginationPanel.add(btnFirst);
        paginationPanel.add(btnPrev);
        paginationPanel.add(lblPageInfo);
        paginationPanel.add(btnNext);
        paginationPanel.add(btnLast);
        paginationPanel.add(lblTotalInfo);
        add(paginationPanel, BorderLayout.SOUTH);

        JPanel searchPanel = new JPanel();
        txtSearch = new JTextField(15);
        comboExamFilter = new JComboBox<>();
        comboExamFilter.addItem("All");
        JButton btnSearch = new JButton("Filter");

        themeToggle = new JToggleButton("Dark Mode");
        searchPanel.add(themeToggle);

        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(txtSearch);
        searchPanel.add(new JLabel("Exam:"));
        searchPanel.add(comboExamFilter);
        searchPanel.add(btnSearch);
        add(searchPanel, BorderLayout.NORTH);

        bindEvents(btnSearch);
        enforceCharLimit(txtQuestionText, 500);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, String label, Component comp) {
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        panel.add(comp, gbc);
    }

    private void enforceCharLimit(final JTextField field, final int maxChars) {
        field.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (field.getText().length() >= maxChars) {
                    e.consume(); // prevent typing
                }
            }
        });

        if (field == txtQuestionText) {
            field.addKeyListener(new KeyAdapter() {
                public void keyReleased(KeyEvent e) {
                    lblCharCount.setText(field.getText().length() + " / " + maxChars);
                }
            });
        }
    }

    private void bindEvents(final JButton btnSearch) {
        btnAdd.addActionListener(e -> addQuestion());
        btnUpdate.addActionListener(e -> updateQuestion());
        btnDelete.addActionListener(e -> deleteQuestion());
        btnClear.addActionListener(e -> clearForm());
        btnSearch.addActionListener(e -> {
            currentPage = 1;
            loadQuestionsFromDatabase();
        });

        themeToggle.addActionListener(e -> {
            isDarkMode = !isDarkMode;
            applyTheme();
        });

        btnFirst.addActionListener(e -> {
            currentPage = 1;
            updateTable();
        });

        btnPrev.addActionListener(e -> {
            if (currentPage > 1) {
                currentPage--;
                updateTable();
            }
        });

        btnNext.addActionListener(e -> {
            if (currentPage < getTotalPages()) {
                currentPage++;
                updateTable();
            }
        });

        btnLast.addActionListener(e -> {
            currentPage = getTotalPages();
            updateTable();
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    comboExamDropdown.setSelectedItem(model.getValueAt(row, 1).toString());
                    txtQuestionText.setText(model.getValueAt(row, 2).toString());
                    txtOptionA.setText(model.getValueAt(row, 3).toString());
                    txtOptionB.setText(model.getValueAt(row, 4).toString());
                    txtOptionC.setText(model.getValueAt(row, 5).toString());
                    txtOptionD.setText(model.getValueAt(row, 6).toString());
                    comboCorrectAnswer.setSelectedItem(model.getValueAt(row, 7).toString());
                    txtMarks.setText(model.getValueAt(row, 8).toString());
                }
            }
        });

        KeyAdapter dynamicCorrectAnswers = new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                updateCorrectAnswerDropdown();
            }
        };

        txtOptionA.addKeyListener(dynamicCorrectAnswers);
        txtOptionB.addKeyListener(dynamicCorrectAnswers);
        txtOptionC.addKeyListener(dynamicCorrectAnswers);
        txtOptionD.addKeyListener(dynamicCorrectAnswers);
    }

    private void updateCorrectAnswerDropdown() {
        String[] opts = new String[]{
            txtOptionA.getText().trim(),
            txtOptionB.getText().trim(),
            txtOptionC.getText().trim(),
            txtOptionD.getText().trim()
        };

        comboCorrectAnswer.removeAllItems();
        String[] labels = {"A", "B", "C", "D"};
        for (int i = 0; i < 4; i++) {
            if (!opts[i].equals("")) comboCorrectAnswer.addItem(labels[i]);
        }
    }

    private boolean validateInputs() {
        boolean valid = true;

        JTextField[] fields = {txtQuestionText, txtOptionA, txtOptionB, txtOptionC, txtOptionD};
        for (int i = 0; i < fields.length; i++) {
            JTextField f = fields[i];
            if (f.getText().trim().isEmpty()) {
                f.setBackground(Color.PINK);
                valid = false;
            } else {
                f.setBackground(Color.WHITE);
            }
        }

        if (comboCorrectAnswer.getSelectedItem() == null) {
            valid = false;
        }

        return valid;
    }

    private void addQuestion() {
        if (!validateInputs()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Actual logic for adding the question
        String query = "INSERT INTO question (ExamID, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectAnswer, Marks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {

            stmt.setInt(1, examMap.get(comboExamDropdown.getSelectedItem().toString()));
            stmt.setString(2, txtQuestionText.getText());
            stmt.setString(3, txtOptionA.getText());
            stmt.setString(4, txtOptionB.getText());
            stmt.setString(5, txtOptionC.getText());
            stmt.setString(6, txtOptionD.getText());
            stmt.setString(7, comboCorrectAnswer.getSelectedItem().toString());
            stmt.setInt(8, Integer.parseInt(txtMarks.getText()));

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Question added successfully.");
            loadQuestionsFromDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving question.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateQuestion() {
        if (!validateInputs()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // If no question selected, return
        if (lastSelectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select a question to update.");
            return;
        }

        String query = "UPDATE Question SET ExamID = ?, QuestionText = ?, OptionA = ?, OptionB = ?, OptionC = ?, OptionD = ?, CorrectAnswer = ?, Marks = ? WHERE QuestionID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {

            stmt.setInt(1, examMap.get(comboExamDropdown.getSelectedItem().toString()));
            stmt.setString(2, txtQuestionText.getText());
            stmt.setString(3, txtOptionA.getText());
            stmt.setString(4, txtOptionB.getText());
            stmt.setString(5, txtOptionC.getText());
            stmt.setString(6, txtOptionD.getText());
            stmt.setString(7, comboCorrectAnswer.getSelectedItem().toString());
            stmt.setInt(8, Integer.parseInt(txtMarks.getText()));
            stmt.setInt(9, lastSelectedId);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Question updated successfully.");
            loadQuestionsFromDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating question.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteQuestion() {
        if (lastSelectedId == null) {
            JOptionPane.showMessageDialog(this, "Please select a question to delete.");
            return;
        }

        String query = "DELETE FROM Question WHERE QuestionID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {

            stmt.setInt(1, lastSelectedId);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Question deleted successfully.");
            loadQuestionsFromDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting question.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        txtQuestionText.setText("");
        txtOptionA.setText("");
        txtOptionB.setText("");
        txtOptionC.setText("");
        txtOptionD.setText("");
        comboCorrectAnswer.removeAllItems();
        lblCharCount.setText("0 / 500");

        JTextField[] fields = {txtQuestionText, txtOptionA, txtOptionB, txtOptionC, txtOptionD};
        for (int i = 0; i < fields.length; i++) {
            fields[i].setBackground(Color.WHITE);
        }

        table.clearSelection();
    }

    private int getTotalPages() {
        return (int) Math.ceil((double) allRows.size() / pageSize);
    }

    private void updateTable() {
        model.setRowCount(0);
        int start = (currentPage - 1) * pageSize;
        int end = Math.min(start + pageSize, allRows.size());

        for (int i = start; i < end; i++) {
            model.addRow((Object[]) allRows.get(i));
        }

        lblPageInfo.setText("Page " + currentPage + " of " + getTotalPages());
        lblTotalInfo.setText("Showing " + model.getRowCount() + " of " + allRows.size() + " question");
    }

    private void reselectRowById(Integer idToSelect) {
        if (idToSelect == null) return;
        for (int i = 0; i < model.getRowCount(); i++) {
            Integer id = ((Integer) model.getValueAt(i, 0));
            if (id.equals(idToSelect)) {
                table.setRowSelectionInterval(i, i);
                break;
            }
        }
    }

    private String getExamNameById(String examId) {
        Iterator it = examMap.keySet().iterator();
        while (it.hasNext()) {
            String name = (String) it.next();
            Integer id = (Integer) examMap.get(name);
            if (id.toString().equals(examId)) {
                return name;
            }
        }
        return "Unknown";
    }

    private void loadExams() {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            con = DatabaseConnection.getConnection();
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT ExamID, ExamName FROM Exam");
            while (rs.next()) {
                String name = rs.getString("ExamName");
                int id = rs.getInt("ExamID");
                examMap.put(name, id);
                comboExamDropdown.addItem(name);
                comboExamFilter.addItem(name);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load exams.");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (stmt != null) stmt.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

private void loadQuestionsFromDatabase() {
    allRows.clear();
    String search = txtSearch.getText().toLowerCase().trim();
    String selectedExam = comboExamFilter.getSelectedItem().toString();

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {
        con = DatabaseConnection.getConnection();
        String sql = "SELECT * FROM Question";
        ps = con.prepareStatement(sql);
        rs = ps.executeQuery();

        while (rs.next()) {
            int qId = rs.getInt("QuestionID");
            String examId = rs.getString("ExamID");
            String examName = getExamNameById(examId);
            String question = rs.getString("QuestionText");
            String a = rs.getString("OptionA");
            String b = rs.getString("OptionB");
            String c = rs.getString("OptionC");
            String d = rs.getString("OptionD");
            String correct = rs.getString("CorrectAnswer");
            int marks = rs.getInt("Marks"); // Fetch marks

            String full = question + a + b + c + d + correct + examName;
            if ((search.equals("") || full.toLowerCase().contains(search)) &&
                (selectedExam.equals("All") || selectedExam.equals(examName))) {
                Object[] row = new Object[]{qId, examName, question, a, b, c, d, correct, marks}; // Add marks to row
                allRows.add(row);
            }
        }

        updateTable();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading questions.");
    } finally {
        try { if (rs != null) rs.close(); } catch (Exception ignored) {}
        try { if (ps != null) ps.close(); } catch (Exception ignored) {}
        try { if (con != null) con.close(); } catch (Exception ignored) {}
    }
}

private void applyDarkTheme() {
    UIManager.put("control", new Color(60, 63, 65));
    UIManager.put("info", new Color(60, 63, 65));
    UIManager.put("nimbusBase", new Color(18, 30, 49));
    UIManager.put("nimbusBlueGrey", new Color(60, 63, 65));
    UIManager.put("nimbusLightBackground", new Color(43, 43, 43));
    UIManager.put("text", Color.WHITE);
    UIManager.put("textForeground", Color.WHITE);
    UIManager.put("Label.foreground", Color.WHITE);
    UIManager.put("Table.background", new Color(43, 43, 43));
    UIManager.put("Table.foreground", Color.WHITE);
    UIManager.put("Table.selectionBackground", new Color(96, 99, 102));
    UIManager.put("Table.selectionForeground", Color.WHITE);
    UIManager.put("Button.background", new Color(70, 70, 70));
    UIManager.put("Button.foreground", Color.WHITE);
    UIManager.put("TextField.background", new Color(60, 63, 65));
    UIManager.put("TextField.foreground", Color.WHITE);
    UIManager.put("ComboBox.background", new Color(60, 63, 65));
    UIManager.put("ComboBox.foreground", Color.WHITE);
    UIManager.put("Panel.background", new Color(43, 43, 43));
    UIManager.put("ScrollBar.thumb", new Color(100, 100, 100));
    UIManager.put("ScrollBar.track", new Color(60, 63, 65));
    
    refreshUI();
}

private void applyTheme() {
    // Define colors for Dark and Light Mode
    Color bgColor, fgColor, fieldBg, buttonBg, buttonFg, tableBg, tableHeaderBg, tableHeaderFg;

    // Dark Mode Colors
    if (isDarkMode) {
        bgColor = new Color(40, 40, 40);         // Main background (dark)
        fgColor = Color.WHITE;                   // Text color (white)
        fieldBg = new Color(60, 60, 60);         // Background for text fields, combo boxes (dark)
        buttonBg = new Color(80, 80, 80);        // Button background (dark)
        buttonFg = Color.WHITE;                  // Button text (white)
        tableBg = new Color(60, 60, 60);         // Table background (dark)
        tableHeaderBg = new Color(50, 50, 50);   // Table header background (dark)
        tableHeaderFg = Color.WHITE;             // Table header text (white)
        themeToggle.setText("Light Mode");       // Toggle button text for light mode
    
    } else { // Light Mode Colors
        bgColor = Color.WHITE;                   // Main background (light)
        fgColor = Color.BLACK;                   // Text color (black)
        fieldBg = Color.WHITE;                   // Background for text fields, combo boxes (light)
        buttonBg = new JButton().getBackground(); // Default button background
        buttonFg = Color.BLACK;                  // Button text (black)
        tableBg = Color.WHITE;                   // Table background (light)
        tableHeaderBg = Color.LIGHT_GRAY;        // Table header background (light)
        tableHeaderFg = Color.BLACK;             // Table header text (black)
        themeToggle.setText("Dark Mode");        // Toggle button text for dark mode
    }

    // Set the background color for the main content panel
    getContentPane().setBackground(bgColor);

    // Style all components recursively (e.g. panels, labels, text fields, combo boxes)
    for (Component comp : getContentPane().getComponents()) {
        if (comp instanceof JPanel) {
            comp.setBackground(bgColor);  // Panel background
            for (Component inner : ((JPanel) comp).getComponents()) {
                styleComponent(inner, fgColor, fieldBg, buttonBg, buttonFg);
            }
        }
    }

    // Style the JTable (table body, column headers, and rows)    
    styleTable(table, tableBg, fgColor, tableHeaderBg, tableHeaderFg);

    // Apply the theme to all buttons (add, update, delete, clear, etc.)
    styleComponent(btnAdd, buttonFg, fieldBg, buttonBg, buttonFg);
    styleComponent(btnUpdate, buttonFg, fieldBg, buttonBg, buttonFg);
    styleComponent(btnDelete, buttonFg, fieldBg, buttonBg, buttonFg);
    styleComponent(btnClear, buttonFg, fieldBg, buttonBg, buttonFg);

    // Apply the theme to all text fields, combo boxes, etc.
    styleComponent(txtSearch, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(txtQuestionText, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(txtOptionA, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(txtOptionB, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(txtOptionC, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(txtOptionD, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(comboCorrectAnswer, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(comboExamDropdown, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(comboExamFilter, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(lblCharCount, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(lblPageInfo, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(lblTotalInfo, fgColor, fieldBg, buttonBg, buttonFg);
    styleComponent(themeToggle, fgColor, fieldBg, buttonBg, buttonFg);
}

private void styleTable(JTable table, Color tableBg, Color tableFg, Color headerBg, Color headerFg) {
    table.setBackground(tableBg); // Set background color for table body
    table.setForeground(tableFg); // Set text color for table body
    table.getTableHeader().setBackground(headerBg); // Set background for table header
    table.getTableHeader().setForeground(headerFg); // Set text color for table header

    // Update table columns headers to match theme
    TableColumnModel columnModel = table.getColumnModel();
    final Color finalHeaderBg = headerBg;  // Declare as final
    final Color finalHeaderFg = headerFg;  // Declare as final
    for (int i = 0; i < columnModel.getColumnCount(); i++) {
        columnModel.getColumn(i).setHeaderRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                component.setBackground(finalHeaderBg);  // Set header background color
                component.setForeground(finalHeaderFg);  // Set header text color
                return component;


                
            }
        });
    }
}




private void applyLightTheme() {
    try {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception e) {
        e.printStackTrace();
    }
    refreshUI();
}

private void refreshUI() {
    SwingUtilities.updateComponentTreeUI(this);
    this.repaint();
}



private void styleComponent(Component comp, Color fg, Color fieldBg, Color buttonBg, Color buttonFg) {
    if (comp instanceof JLabel) {
        // Set foreground color for labels
        comp.setForeground(fg);
    } else if (comp instanceof JTextField) {
        // Set background and text color for text fields
        comp.setBackground(fieldBg);
        comp.setForeground(fg);
        ((JTextField) comp).setCaretColor(fg);  // Set caret (cursor) color for text fields
    } else if (comp instanceof JComboBox) {
        // Set background and text color for combo boxes
        comp.setBackground(fieldBg);
        comp.setForeground(fg);
    } else if (comp instanceof JButton) {
        // Set background, text color, and font for buttons
        comp.setBackground(buttonBg);
        comp.setForeground(buttonFg);
        comp.setFont(new Font("Arial", Font.BOLD, 12));  // Optional: Set font for buttons
    } else if (comp instanceof JToggleButton) {
        // For toggle buttons (theme toggle)
        comp.setBackground(buttonBg);
        comp.setForeground(buttonFg);
    }
}

    public static void main(String[] args) {
        new QuestionManager();
    }
}


