package ui;

import database.DatabaseConnection;
import model.AdminLogin;
import model.ExamForm;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminPanel {
    private JFrame frame;
    private JTable examTable, questionTable, studentTable, resultTable;
    private DefaultTableModel examModel, questionModel, studentModel, resultModel;
    private boolean isDarkMode = false;
    private final String loggedInAdmin;

    public AdminPanel(String username) {
        this.loggedInAdmin = username;
        frame = new JFrame("Admin Panel - Logged in as " + username);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int confirm = JOptionPane.showConfirmDialog(
                        frame,
                        "Are you sure you want to exit?",
                        "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    frame.dispose();
                }
            }
        });

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.add("Exams", createExamPanel());
        tabbedPane.add("Questions", createQuestionPanel());
        tabbedPane.add("Students", createStudentPanel());
        tabbedPane.add("Results", createResultPanel());

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new AdminLogin();
            }
        });

        final JToggleButton toggleTheme = new JToggleButton("Dark Mode");
        toggleTheme.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isDarkMode = !isDarkMode;
                toggleDarkMode(frame.getContentPane());
                toggleTheme.setText(isDarkMode ? "Light Mode" : "Dark Mode");
            }
        });

        bottomPanel.add(toggleTheme);
        bottomPanel.add(logoutButton);

        frame.add(tabbedPane, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createExamPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        examModel = new DefaultTableModel(new Object[]{"Exam ID", "Exam Name", "Duration", "Edit", "Delete"}, 0);
        examTable = new JTable(examModel);
        makeTableNice(examTable);
        loadExams();

        JButton addExam = new JButton("Add Exam");
        addExam.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ExamForm(examModel, loggedInAdmin);

            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(addExam);
        panel.add(new JScrollPane(examTable), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createQuestionPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        questionModel = new DefaultTableModel(new Object[]{"Question ID", "Exam ID", "Question Text", "Correct Answer"}, 0);
        questionTable = new JTable(questionModel);
        makeTableNice(questionTable);
        loadQuestions();

        JButton manageQuestions = new JButton("Manage Questions");
        manageQuestions.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new QuestionManager();
            }
        });

        JButton assignExam = new JButton("Assign Exam");
        assignExam.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AssignExamForm();
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(manageQuestions);
        buttonPanel.add(assignExam);

        panel.add(new JScrollPane(questionTable), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        studentModel = new DefaultTableModel(new Object[]{"Student ID", "Name", "Email"}, 0);
        studentTable = new JTable(studentModel);
        makeTableNice(studentTable);
        loadStudents();
        panel.add(new JScrollPane(studentTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createResultPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        resultModel = new DefaultTableModel(new Object[]{"Result ID", "Student ID", "Exam ID", "Score"}, 0);
        resultTable = new JTable(resultModel);
        makeTableNice(resultTable);
        loadResults();
        panel.add(new JScrollPane(resultTable), BorderLayout.CENTER);
        return panel;
    }

    private void makeTableNice(final JTable table) {
        table.setDefaultEditor(Object.class, null);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setAutoCreateRowSorter(true);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());

                if (col == table.getColumnCount() - 2) {
                    int examId = Integer.parseInt(table.getValueAt(row, 0).toString());
                    String name = table.getValueAt(row, 1).toString();
                    int duration = Integer.parseInt(table.getValueAt(row, 2).toString());
                    editExam(examId, name, duration, row);
                }

                if (col == table.getColumnCount() - 1) {
                    int examId = Integer.parseInt(table.getValueAt(row, 0).toString());
                    int confirm = JOptionPane.showConfirmDialog(table, "Delete this exam?", "Confirm", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        deleteExam(examId, row);
                    }
                }
            }
        });
    }

    private void editExam(int examId, String name, int duration, int rowIndex) {
        String newName = JOptionPane.showInputDialog(frame, "Edit Exam Name:", name);
        String newDurationStr = JOptionPane.showInputDialog(frame, "Edit Duration (minutes):", duration);

        if (newName != null && newDurationStr != null) {
            try {
                int newDuration = Integer.parseInt(newDurationStr);
                Connection con = DatabaseConnection.getConnection();
                PreparedStatement pst = con.prepareStatement("UPDATE Exam SET ExamName=?, Duration=? WHERE ExamID=?");
                pst.setString(1, newName);
                pst.setInt(2, newDuration);
                pst.setInt(3, examId);
                pst.executeUpdate();
                pst.close();
                DatabaseConnection.closeConnection();

                examModel.setValueAt(newName, rowIndex, 1);
                examModel.setValueAt(newDuration, rowIndex, 2);
                JOptionPane.showMessageDialog(frame, "Exam updated!");
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error updating exam.");
            }
        }
    }

    private void deleteExam(int examId, int rowIndex) {
        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("DELETE FROM Exam WHERE ExamID=?");
            pst.setInt(1, examId);
            pst.executeUpdate();
            pst.close();
            DatabaseConnection.closeConnection();

            examModel.removeRow(rowIndex);
            JOptionPane.showMessageDialog(frame, "Exam deleted!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error deleting exam.");
        }
    }

    private void toggleDarkMode(Container container) {
        Color bg = isDarkMode ? Color.DARK_GRAY : Color.WHITE;
        Color fg = isDarkMode ? Color.WHITE : Color.BLACK;

        for (Component c : container.getComponents()) {
            c.setBackground(bg);
            c.setForeground(fg);
            if (c instanceof Container) {
                toggleDarkMode((Container) c);
            }
        }
        container.setBackground(bg);
        container.setForeground(fg);
    }

    private void loadExams() {
        examModel.setRowCount(0);
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement("SELECT * FROM Exam WHERE CreatedBy=?");
            pst.setString(1, loggedInAdmin);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                examModel.addRow(new Object[]{
                        rs.getInt("ExamID"),
                        rs.getString("ExamName"),
                        rs.getInt("Duration"),
                        "Edit",
                        "Delete"
                });
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadQuestions() {
        questionModel.setRowCount(0);
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                "SELECT * FROM Question WHERE ExamID IN (SELECT ExamID FROM Exam WHERE CreatedBy=?)");
            pst.setString(1, loggedInAdmin);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                questionModel.addRow(new Object[]{
                        rs.getInt("QuestionID"),
                        rs.getInt("ExamID"),
                        rs.getString("QuestionText"),
                        rs.getString("CorrectAnswer")
                });
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadStudents() {
        studentModel.setRowCount(0);
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement("SELECT * FROM Student"); 
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                studentModel.addRow(new Object[]{
                        rs.getInt("StudentID"),
                        rs.getString("FullName"),
                        rs.getString("Email")
                });
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadResults() {
        resultModel.setRowCount(0);
        try (Connection con = DatabaseConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                "SELECT * FROM Result WHERE ExamID IN (SELECT ExamID FROM Exam WHERE CreatedBy=?)");
            pst.setString(1, loggedInAdmin);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                resultModel.addRow(new Object[]{
                        rs.getInt("ResultID"),
                        rs.getInt("StudentID"),
                        rs.getInt("ExamID"),
                        rs.getInt("Score")
                });
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new AdminPanel("admin");
    }
}
